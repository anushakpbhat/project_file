package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employee")
public class Employee {
	String first_name,middlename,last_name,father_name,mother_name,date;
	@Id 
	String emp_id;
	String adhar_card,pan_card,gender,nationality,mobile_number,address,email_id;
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getMother_name() {
		return mother_name;
	}
	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getAdhar_card() {
		return adhar_card;
	}
	public void setAdhar_card(String adhar_card) {
		this.adhar_card = adhar_card;
	}
	public String getPan_card() {
		return pan_card;
	}
	public void setPan_card(String pan_card) {
		this.pan_card = pan_card;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public Employee() {}
	public Employee(String first_name, String middlename, String last_name, String father_name, String mother_name,
			String date, String emp_id, String adhar_card, String pan_card, String gender, String nationality,
			String mobile_number, String address, String email_id) {
		super();
		this.first_name = first_name;
		this.middlename = middlename;
		this.last_name = last_name;
		this.father_name = father_name;
		this.mother_name = mother_name;
		this.date = date;
		this.emp_id = emp_id;
		this.adhar_card = adhar_card;
		this.pan_card = pan_card;
		this.gender = gender;
		this.nationality = nationality;
		this.mobile_number = mobile_number;
		this.address = address;
		this.email_id = email_id;
	}
	

}
